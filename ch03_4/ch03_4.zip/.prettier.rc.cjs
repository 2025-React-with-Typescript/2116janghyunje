module.exports = {
bracketSpacing: false,
jsxBracketSameLine: true,
singleQuote: true,
tailingComma: false,
arrowParens: 'avoid',
semi: false,
printWidth: 90,
};